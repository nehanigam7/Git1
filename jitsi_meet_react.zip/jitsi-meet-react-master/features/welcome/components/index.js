export { default as WelcomePage } from './WelcomePage';
