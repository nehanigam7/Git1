export { default as FilmStrip } from './FilmStrip';
