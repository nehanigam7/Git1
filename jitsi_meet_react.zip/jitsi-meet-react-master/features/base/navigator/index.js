export { default as RouteRegistry } from './RouteRegistry';
