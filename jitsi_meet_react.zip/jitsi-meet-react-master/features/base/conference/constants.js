/**
 * The command type for updating a participant's email address.
 *
 * @type {string}
 */
export const EMAIL_COMMAND = 'email';
