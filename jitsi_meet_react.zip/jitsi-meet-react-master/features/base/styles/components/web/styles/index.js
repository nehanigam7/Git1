require('style!./FontAwesome.css');
