/**
 * The application color palette.
 */
export const ColorPalette = {
    appBackground: '#111111',
    buttonUnderlay: '#495258',
    jitsiBlue: '#00ccff',
    jitsiDarkGrey: '#555555',
    jitsiRed: '#D00000',
    jitsiToggled: '#495258'
};
