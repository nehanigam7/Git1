require('./polyfills-browser');
require('./polyfills-browserify');
