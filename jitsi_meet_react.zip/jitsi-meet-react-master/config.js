/* global config */

// For legacy reasons, use jitsi-meet's global variable config.
export default typeof config === 'object' ? config : undefined;
