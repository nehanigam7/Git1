# jitsi-meet-react

## Launching the App

- For Android: `npm run start:android`
- For iOS: `npm run start:ios`
- For Web: `npm run start:web`
